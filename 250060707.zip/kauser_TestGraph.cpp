/*
Author: Jameela Kauser
Date: 4/25/2024
Description: Main fucntion to connect all the files and print menu to prompt user for choice and do the necessary
*/
#include "MatrixGraph_kauser.h"
#include <iostream>
#include <iomanip> 
#include <fstream>
#include <sstream>
#include <limits>
using namespace std;

int main(int argc, char* argv[])//main function
{
    string graphType = argv[1];  
    string filePath = argv[2];
    bool undirected= false;
     if (argc > 3 &&  string(argv[3]) == "-ud")
     {
        undirected = true;
     }
      bool weighted=false;
     if ( graphType == "-w")
     {
         weighted = 1;
     }
    ifstream file(filePath);
    int vertices;
    int edges;
    file >> vertices >> edges;
    MatrixGraph graph(vertices, undirected);
    int v1;
    int v2;
    int count=0;
    float weight;
    if (weighted) 
    {
    for (int i = 0; i < edges; i++) 
    {
        file >> v1 >> v2 >> weight;
        graph.addEdge(v1 - 1, v2 - 1, weight);
        if (undirected)
            graph.addEdge(v2 - 1, v1 - 1, weight);
    }
    }
    else 
    {
        for (int i = 0; i < edges; i++) 
        {
            file >> v1 >> v2;
            graph.addEdge(v1 - 1, v2 - 1, 1);  
            if (undirected)
                graph.addEdge(v2 - 1, v1 - 1, 1);
        }
    }
    file.close();
    int choice;
    string filename;
    ofstream outFile;
    ofstream outFileApp;
    do//prints menu
    {
        std::cout<<"Welcome to the Graph tester!\n";
        std::cout << "1) Print the graph\n";
        std::cout << "2) Find a path\n";
        std::cout << "3) Start a file\n";
        std::cout << "4) Add a path to the file\n";
        std::cout << "0) Quit\n";
        std::cin >> choice;
        switch(choice)//switch case to check the necessary action 
        {
            case 1://for choice 1 to print graph
            cout<< graph.toString();
            break;
            case 2://for choice 2 to find path
            cin>>v1>>v2;
            try 
            {
            vector<int> bfsPath = graph.getBFSPath(v1,v2);
            if(bfsPath.empty())
            {
                cout<<"No path from "<<v1<<" to "<<v2<<".\n";
            }
            else
            {
                float weight = 0.00;
                cout<<"["<< setw(2)<<bfsPath[0]+1<<":"<<setw(6)<<std::fixed << std::setprecision(2) << static_cast<double>(0.00)<<"]";
                for (int i = 1; i < bfsPath.size(); i++) 
                {
                    weight = weight + graph.getEdgeWeight(bfsPath[i-1],bfsPath[i]);
                    cout<<"==>["<< setw(2)<<bfsPath[i]+1<<":"<<setw(6)<<std::fixed << std::setprecision(2) << static_cast<double>(weight)<<"]";
                }
                cout << endl;
            }
            }
            catch (exception& e) 
            {
            }
            break;
            case 3://for choice 3 to start file
            cin >> filename;
            outFile.open(filename);
            for (int i = 0; i < vertices; i++) 
            {
                for (int j=0; j< vertices ; j++)
                {
                    if(graph.adjacent(i,j)) 
                    {
                        count++;
                    }
                }
            }
            outFile << vertices << " " << count << "\n";
            for (int i = 0; i < vertices; i++) 
            {
                for (int j=0; j< vertices ; j++)
                {
                    if(graph.adjacent(i,j)) 
                    {
                      if (weighted)
                       {
                          outFile << i+1 << " " << j+1 << " " << std::fixed << std::setprecision(6) << static_cast<double>(graph.getEdgeWeight(i,j)) << "\n";                 
                       }
                      else 
                       {
                          outFile << i+1 << " " << j+1 << " " << "\n";
                       }       
                   }
               }
            }
            outFile.close();
            break;
            case 4://for choice 4 to add path to file
            if (!filename.empty()) 
            {
            cin>>v1>>v2;
            outFileApp.open(filename,ios::app);
            try 
            {
                vector<int> bfsPath = graph.getBFSPath(v1,v2);
                if(bfsPath.empty())
                {
                    outFileApp<<"No path from "<<v1<<" to "<<v2<<".\n";
                }
                else
                {
                    float weight = 0.00;
                    outFileApp<<"["<< setw(2)<<bfsPath[0]+1<<":"<<setw(6)<<std::fixed << std::setprecision(2) << static_cast<double>(0.00)<<"]";
                    for (int i = 1; i < bfsPath.size(); i++) 
                            {
                                weight = weight + graph.getEdgeWeight(bfsPath[i-1],bfsPath[i]);
                                outFileApp<<"==>["<< setw(2)<<bfsPath[i]+1<<":"<<setw(6)<<std::fixed << std::setprecision(2) << static_cast<double>(weight)<<"]";
                            }
                        outFileApp << endl;   
                }
            }
            catch (exception& e) 
            {
            }
            outFileApp.close();
            }
            else 
                {
                    cout << "No file has been created yet." << endl;
                }
            break;
            case 0://for choice to exit
            exit(0);
            break;
            case 9999://cheat code
            graph.printRaw();
            break;
            default:
                cout << "Invalid choice. Please try again.\n";
        }
    }
     while(choice != 0);
    }