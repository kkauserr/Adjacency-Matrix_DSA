/*
Author: Jameela Kauser
Date: 4/25/2024
Description: .h file declaring necessary methods for matrix graph
*/
#ifndef MATRIXGRAPH_H
#define MATRIXGRAPH_H
#include <vector>
#include<string>
class MatrixGraph
{
    private:
        std::vector<std::vector<float>> matrix;
        bool directed;
        int vertice;
    public:
        MatrixGraph(int vert, bool isDirected);
        void addEdge(int frm, int to);
        void addEdge(int frm, int to, float wght);
        void removeEdge(int frm, int to);
        float getEdgeWeight(int frm, int to);
        void setEdgeWeight(int frm, int to, float wght);
        bool adjacent(int frm, int to);
        std:: string toString();
        void printRaw();
        bool pathExists(int frm,int to);
        std::vector<int> getBFSPath(int strt, int end);
};
#endif